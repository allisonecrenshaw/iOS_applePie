//
//  Game.swift
//  ApplePie_CrenshawAllison
//
//  Created by Xcode Student on 11/7/19.
//  Copyright © 2019 Allison Crenshaw. All rights reserved.
//

import Foundation

struct Game {
    var word: String
    var incorrectMovesRemaining: Int
    var guessedLetters: [Character]
    
    var formattedWord: String {
        var guessedWord = ""
        for letter in word {
            if guessedLetters.contains(letter) {
                guessedWord += "\(letter)"
            } else {
                guessedWord += "_"
            }
        } // end of for loop
        return guessedWord
    } // end of formatted word
    
    mutating func playerGuessed(letter: Character) {
        guessedLetters.append(letter)
        if !word.contains(letter) {
            incorrectMovesRemaining -= 1
        } // end of if
    } // end of playerGuessed()
    
} // end of Game struct
